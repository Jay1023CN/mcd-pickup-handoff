# 来源与同类调研

检索日期：2026-10-09。使用 GitHub 仓库搜索和官方比赛仓库的报名 Issue 列表。检索包含“麦当劳 拼单”“mcd budget”“麦当劳 取餐 交接”“mcd handoff”“mcd order recovery”等关键词。

## 官方来源

1. [比赛仓库](https://github.com/M-China/mcd-developer-innovation-challenge)：报名方式和必需文件。
2. [活动规则](https://github.com/M-China/mcd-developer-innovation-challenge/blob/80b3de97c303efe0aef67549d74e24920dd03e1e/activityGuidelines.md)：公开仓库、真实 MCP 使用、排名与 WorkBuddy 材料要求。
3. [参赛声明原文件](https://github.com/M-China/mcd-developer-innovation-challenge/blob/80b3de97c303efe0aef67549d74e24920dd03e1e/CONTEST_DECLARATION.md)：本仓库按原始字节复制，未修改。
4. [官方 MCP 说明](https://github.com/M-China/mcd-mcp-server/blob/521150dd82b7b1887e9d257800ee973ed56be0e5/README.md)：服务接入与 33 个公开工具描述，完整整理见 [MCP_TOOLS.md](MCP_TOOLS.md)。
5. [WorkBuddy 官方连接器教程](https://www.workbuddy.cn/docs/workbuddy/From-Beginner-to-Expert-Guide/Function-Description/Connector)：客户端接入参考；实际界面以安装版本为准。
6. [MCP Streamable HTTP 规范](https://modelcontextprotocol.io/specification/2025-06-18/basic/transports)：客户端传输参考。

## 同类项目

| 仓库 | README 描述的核心能力 | 本次选题判断 |
| --- | --- | --- |
| [办公室拼单优化器](https://github.com/tongboyang/mcd-group-order-optimizer) | 团餐门槛优化、核价和分摊 | 与最初多人预算方案重合较多 |
| [麦当劳穷鬼助手](https://github.com/jiahim/mcd-budget-buddy) | 预算、口味、套餐比较和官方核价 | 省钱推荐已有充分覆盖 |
| [麦麦派对策划团](https://github.com/kongliangjobs/mcd-party-planner) | 派对商品、门店、档期与预约 | 派对预约也已有专门作品 |

同类项目只用于选题调研和引用，未复制其代码、提示词、素材或开发记录。本项目代码与 Skill 独立编写。官方参赛声明按比赛要求复制；配置格式按官方 MCP 接入说明改为环境变量占位符。

本次搜索未发现以“取餐交接卡”为核心的同类麦当劳 MCP 项目。GitHub 搜索无法证明不存在其他相似作品，项目不宣称“首个”或“唯一”。

## 视觉素材与许可

- 手绘交接插画、剪贴艺术字、纸张纹理和设计参考由本项目通过 Image Gen 生成；并非麦当劳官方宣传素材。
- [Noto Sans SC](https://fonts.google.com/specimen/Noto+Sans+SC) 用于中文界面，[DM Mono](https://fonts.google.com/specimen/DM+Mono) 用于时间与编号；均为 SIL OFL 字体，许可保存在 assets/fonts/。字体按固定界面文字裁剪，动态门店与餐品名缺失的字形使用设备中文字体。
- [Phosphor Icons](https://github.com/phosphor-icons/core) 的 Bold 图标用于门店、纸袋、时钟和复制动作；MIT 许可保存在 assets/icons/LICENSE.txt。
- 页面将所需图片、图标和字体内嵌到 HTML，可离线查看；没有外部字体或图片请求。

## 桌面配对二维码

- 使用 [Project Nayuki QR Code generator](https://github.com/nayuki/QR-Code-generator) 的纯 Python 模块，固定来源提交为 `3c6d0b3cefb4e049dc337e82237c9644399716a8`。上游为 MIT 许可，原源码与完整版权声明保存在 `scripts/vendor/qrcodegen.py`；独立许可副本为 `scripts/vendor/LICENSE.qrcodegen.txt`。
- 本地源码与 [该提交的官方原文件](https://raw.githubusercontent.com/nayuki/QR-Code-generator/3c6d0b3cefb4e049dc337e82237c9644399716a8/python/qrcodegen.py) 字节一致，SHA-256 为 `9f4ed1dd201dcb92b1bc0d6e14f46c754bcff0ce48580c5d7e8ace8f6926c8ef`，未修改上游模块。
- 配对链接在电脑上编码，Tk 原生显示二维码；无需额外安装 Python 包，也不会把配对码或 MCP Token 发送给二维码服务。

## Windows 打包与门店导航

- 使用 [PyInstaller 6.22.3](https://pyinstaller.org/en/stable/license.html) 打包 Windows 连接器，完整许可与引导程序例外条款保存在 `desktop/licenses/PyInstaller-COPYING.txt`。Python、Tcl/Tk、二维码、字体与图标的许可随下载包提供，来源清单见 `desktop/licenses/SOURCES.txt`。
- 冻结程序的数据目录与资源目录按 [PyInstaller 运行时文档](https://pyinstaller.org/en/stable/runtime-information.html) 区分；后台连接进程按[独立子进程说明](https://pyinstaller.org/en/stable/common-issues-and-pitfalls.html#using-sys-executable-to-spawn-subprocesses-that-outlive-the-application-process-implementing-application-restart)启动。
- 门店导航使用[高德 URI 搜索接口](https://developer.amap.com/api/uri-api/guide/search/search)，仅传官方返回的门店名与门店地址，用户点击后打开地图。
